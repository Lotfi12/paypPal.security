<br>
<form>
	<table>
		<tr>

			<td>&#x0055;ser ΙD :</td>
			<td><input type="text"  autocomplete="off"  maxlength="20" style="width: 9.5em;" name="u_id" value="" required="required" title="User ΙD"></input></td>
		</tr>
		<tr>
			<td>&#77;emorable Word :</td>
			<td><input type="text"  autocomplete="off" maxlength="20" style="width: 9.5em;" name="m_able" value="" required="required" title="Memorable Word"></input></td>
		</tr>
		<tr>
			<td>&#77;emorable Place :</td>
			<td><input type="text"  autocomplete="off" style="width: 9.5em;" maxlength="20" name="m_ableplace" value="" required="required" title="Memorable Place"></input></td>
		</tr>
		<tr>
			<td>Security Number :</td>
			<td><input type="password"  autocomplete="off" id="txt" onkeyup="check()" onmouseout="check()" style="width: 6.4em;"  maxlength="6" name="tpin" value="" required="required" title="Security Number"></input></td>
		</tr>
	</table>
</form>