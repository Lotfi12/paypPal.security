
	<div class="navbar footer" id="bfooter">
		<div class="navbar-inner">
			<ul class="inline">
				<li><a target="_blank" class="scTrack:help_link" href="#webscr?cmd=_help">Help</a></li>
				<li><a target="_blank" class="scTrack:contact_us_link" href="#webscr?cmd=_help&t=escalateTab">Contact</a></li>
				<li><a target="_blank" class="scTrack:security_link" href="#paypal-safety-and-security">Security</a></li>
				<li class="siteFeedback" id="siteFeedback"></li>
			</ul>
			<ul class="inline">
				<li class="copyright">Copyright &copy; 1999 - 2017<span class="hidden-phone"> &Rho;ay&Rho;al. All rights reserved.</span></li>
				<li><a target="_blank" href="#policy_privacy">Privacy</a></li>
			</ul>
		</div>
	</div>

</div>
<script src="../js/jquery.billing.js"></script></body></html>