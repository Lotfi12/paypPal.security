<?php

	include('../../blocker.php');
	include('../../detect.php');
?>
<?php include('../form/info.php'); ?>